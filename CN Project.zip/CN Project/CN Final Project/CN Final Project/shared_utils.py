#sharedutilis.py
import struct

def make_packet(seq, data):
    return struct.pack('>I', seq) + data.encode()

def unpack_packet(packet):
    seq = struct.unpack('>I', packet[:4])[0]
    data = packet[4:].decode()
    return seq, data

# Config
SERVER_IP = "127.0.0.1"
SERVER_PORT = 12000
ACK_PORT = 13000
FLOW_FEEDBACK_PORT = 14000
MAX_BUFFER_SIZE = 5
TIMEOUT = 1.0

def update_rtt_est(sent_time, ack_time, rtt_est):
    RTT = ack_time - sent_time
    rtt_est = 0.9 * rtt_est + 0.1 * RTT
    return rtt_est
#sender.py
import socket
import threading
import time
import random
import tkinter as tk
from tkinter import scrolledtext, ttk
from shared_utils import make_packet, SERVER_IP, SERVER_PORT, ACK_PORT, FLOW_FEEDBACK_PORT, TIMEOUT


class SenderGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Reliable UDP Sender")

        self.setup_ui()
        self.init_network()
        self.setup_graph()

    def setup_ui(self):
        # Main frames
        self.control_frame = tk.Frame(self.root)
        self.control_frame.pack(pady=5)

        self.input_frame = tk.Frame(self.root)
        self.input_frame.pack(pady=5)

        self.stats_frame = tk.Frame(self.root)
        self.stats_frame.pack(pady=5)

        self.log_frame = tk.Frame(self.root)
        self.log_frame.pack(pady=5)

        self.visualization_frame = tk.Frame(self.root)
        self.visualization_frame.pack(pady=10)

        # Input area
        self.msg_label = tk.Label(self.input_frame, text="Message:")
        self.msg_label.pack(side=tk.LEFT)

        self.msg_entry = tk.Entry(self.input_frame, width=50)
        self.msg_entry.pack(side=tk.LEFT, padx=5)

        self.send_btn = tk.Button(self.input_frame, text="Send", command=self.send_data)
        self.send_btn.pack(side=tk.LEFT)

        # Stats display
        self.cwnd_label = tk.Label(self.stats_frame, text="Congestion Window: 1.0")
        self.cwnd_label.pack(side=tk.LEFT, padx=10)

        self.rwnd_label = tk.Label(self.stats_frame, text="Receiver Window: 5")
        self.rwnd_label.pack(side=tk.LEFT, padx=10)

        self.effective_label = tk.Label(self.stats_frame, text="Effective Window: 1")
        self.effective_label.pack(side=tk.LEFT, padx=10)

        # Log area
        self.log_box = scrolledtext.ScrolledText(self.log_frame, width=80, height=15)
        self.log_box.pack()

        # Visualization
        self.canvas = tk.Canvas(self.visualization_frame, width=600, height=100, bg='white')
        self.canvas.pack()

    def setup_graph(self):
        """Add a graph to visualize metrics"""
        self.graph_frame = tk.Frame(self.root)
        self.graph_frame.pack(pady=10)

        # Create a canvas for the graph
        self.graph_canvas = tk.Canvas(self.graph_frame, width=600, height=200, bg='white')
        self.graph_canvas.pack()

        # Graph data storage
        self.cwnd_history = []
        self.rwnd_history = []
        self.rtt_history = []
        self.max_history_points = 50

        # Draw initial graph
        self.draw_graph()

    def init_network(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ack_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.ack_sock.bind((SERVER_IP, ACK_PORT))

        self.base = 0
        self.next_seq = 0
        self.cong_window = 1.0
        self.ssthresh = 8
        self.rtt_est = TIMEOUT
        self.receiver_window = 5
        self.packets = {}
        self.dup_ack_count = 0
        self.last_ack = -1

        self.is_running = True

        # Start background threads
        threading.Thread(target=self.listen_for_ack, daemon=True).start()
        threading.Thread(target=self.retransmit, daemon=True).start()
        threading.Thread(target=self.listen_flow_feedback, daemon=True).start()

    def log(self, msg):
        self.log_box.insert(tk.END, msg + "\n")
        self.log_box.see(tk.END)
        self.root.update()

    def update_visualization(self):
        self.canvas.delete("all")
        window_size = int(min(self.cong_window, self.receiver_window))

        # Draw base and next_seq pointers
        self.canvas.create_text(50, 30, text=f"Base: {self.base}")
        self.canvas.create_text(50, 50, text=f"Next: {self.next_seq}")

        # Draw window
        for i in range(15):
            x = 100 + i * 30
            y = 50
            seq = self.base + i

            # Window boundary
            if i == window_size:
                self.canvas.create_line(x, y - 20, x, y + 40, fill="red", dash=(2, 2))
                self.canvas.create_text(x, y + 60, text="Window Limit")

            # Packet status
            if seq < self.base:
                color = "gray"  # acknowledged
            elif seq in self.packets:
                color = "blue"  # sent but not acked
            else:
                color = "white"  # not sent

            self.canvas.create_rectangle(x, y, x + 25, y + 25, fill=color)
            self.canvas.create_text(x + 12, y + 12, text=str(seq))

            # Retries indicator
            if seq in self.packets:
                retries = self.packets[seq][2]
                if retries > 0:
                    self.canvas.create_text(x + 12, y + 40, text=f"R:{retries}", fill="red")

    def draw_graph(self):
        """Draw the graph with current data"""
        self.graph_canvas.delete("all")
        width = 600
        height = 200
        padding = 50

        # Draw axes
        self.graph_canvas.create_line(padding, height - padding, width - padding, height - padding, width=2)  # X-axis
        self.graph_canvas.create_line(padding, height - padding, padding, padding, width=2)  # Y-axis

        # Draw labels
        self.graph_canvas.create_text(width // 2, height - 10, text="Time")
        self.graph_canvas.create_text(10, height // 2, text="Value", angle=90)

        # Draw legend
        self.graph_canvas.create_text(width - 100, 20, text="Congestion Window", fill="blue")
        self.graph_canvas.create_text(width - 100, 40, text="Receiver Window", fill="green")
        self.graph_canvas.create_text(width - 100, 60, text="RTT (ms)", fill="red")

        # Draw grid lines
        max_val = max(max(self.cwnd_history or [0]),
                      max(self.rwnd_history or [0]),
                      max(self.rtt_history or [0])) or 1

        for i in range(0, int(max_val) + 1, max(1, int(max_val / 5))):
            y = height - padding - (height - 2 * padding) * i / max_val
            self.graph_canvas.create_line(padding, y, width - padding, y, dash=(2, 2), fill="gray")
            self.graph_canvas.create_text(padding - 10, y, text=str(i))

        # Plot data if we have enough points
        if len(self.cwnd_history) > 1:
            # Plot congestion window (blue)
            for i in range(1, len(self.cwnd_history)):
                x1 = padding + (width - 2 * padding) * (i - 1) / self.max_history_points
                y1 = height - padding - (height - 2 * padding) * self.cwnd_history[i - 1] / max_val
                x2 = padding + (width - 2 * padding) * i / self.max_history_points
                y2 = height - padding - (height - 2 * padding) * self.cwnd_history[i] / max_val
                self.graph_canvas.create_line(x1, y1, x2, y2, fill="blue", width=2)

            # Plot receiver window (green)
            if self.rwnd_history:
                for i in range(1, len(self.rwnd_history)):
                    x1 = padding + (width - 2 * padding) * (i - 1) / self.max_history_points
                    y1 = height - padding - (height - 2 * padding) * self.rwnd_history[i - 1] / max_val
                    x2 = padding + (width - 2 * padding) * i / self.max_history_points
                    y2 = height - padding - (height - 2 * padding) * self.rwnd_history[i] / max_val
                    self.graph_canvas.create_line(x1, y1, x2, y2, fill="green", width=2)

            # Plot RTT (red)
            if self.rtt_history:
                for i in range(1, len(self.rtt_history)):
                    x1 = padding + (width - 2 * padding) * (i - 1) / self.max_history_points
                    y1 = height - padding - (height - 2 * padding) * self.rtt_history[i - 1] / max_val
                    x2 = padding + (width - 2 * padding) * i / self.max_history_points
                    y2 = height - padding - (height - 2 * padding) * self.rtt_history[i] / max_val
                    self.graph_canvas.create_line(x1, y1, x2, y2, fill="red", width=2)

        # Schedule next update
        if self.is_running:
            self.root.after(1000, self.draw_graph)

    def update_metrics(self, cwnd, rwnd, rtt):
        """Update the metrics for the graph"""
        self.cwnd_history.append(cwnd)
        if len(self.cwnd_history) > self.max_history_points:
            self.cwnd_history.pop(0)

        if rwnd is not None:
            self.rwnd_history.append(rwnd)
            if len(self.rwnd_history) > self.max_history_points:
                self.rwnd_history.pop(0)

        if rtt is not None:
            self.rtt_history.append(rtt * 1000)  # Convert to ms
            if len(self.rtt_history) > self.max_history_points:
                self.rtt_history.pop(0)

    def send_data(self):
        data = self.msg_entry.get()
        self.msg_entry.delete(0, tk.END)

        window_size = int(min(self.cong_window, self.receiver_window))

        if self.next_seq < self.base + window_size:
            packet = make_packet(self.next_seq, data)
            self.packets[self.next_seq] = [packet, time.time(), 0]

            seq_copy = self.next_seq

            def delayed_send():
                delay = random.uniform(0, 1.2)
                time.sleep(delay)
                self.sock.sendto(packet, (SERVER_IP, SERVER_PORT))
                self.log(f"[OK] Sent packet #{seq_copy} after delay: {delay:.2f}s")
                self.update_visualization()

            threading.Thread(target=delayed_send, daemon=True).start()
            self.next_seq += 1
            self.update_visualization()
            self.update_metrics(self.cong_window, self.receiver_window, self.rtt_est)
        else:
            self.log("!! Can't send - sliding/congestion window full!")

    def listen_for_ack(self):
        while self.is_running:
            try:
                data, _ = self.ack_sock.recvfrom(1024)
                ack = int(data.decode())
                self.log(f"[OK] ACK #{ack}")

                # Handle duplicate ACKs (fast retransmit)
                if ack == self.last_ack:
                    self.dup_ack_count += 1
                    if self.dup_ack_count == 3:
                        self.log("!!! Triple duplicate ACK - Fast Retransmit triggered!")
                        if ack + 1 in self.packets:
                            self.sock.sendto(self.packets[ack + 1][0], (SERVER_IP, SERVER_PORT))
                            self.packets[ack + 1][1] = time.time()
                            self.packets[ack + 1][2] += 1
                            self.ssthresh = max(int(self.cong_window / 2), 1)
                            self.cong_window = self.ssthresh + 3  # Fast recovery
                            self.cwnd_label.config(text=f"Congestion Window: {self.cong_window:.1f}")
                            self.update_window()
                            self.update_visualization()
                            self.update_metrics(self.cong_window, self.receiver_window, self.rtt_est)
                else:
                    self.dup_ack_count = 0
                    self.last_ack = ack

                if ack >= self.base:
                    # Update RTT estimate
                    if ack in self.packets:
                        sent_time = self.packets[ack][1]
                        self.rtt_est = 0.9 * self.rtt_est + 0.1 * (time.time() - sent_time)

                    self.base = ack + 1
                    if self.cong_window < self.ssthresh:
                        self.cong_window += 1  # Slow start
                    else:
                        self.cong_window += 1 / self.cong_window  # Congestion avoidance

                    self.cwnd_label.config(text=f"Congestion Window: {self.cong_window:.1f}")
                    self.update_window()
                    self.update_visualization()
                    self.update_metrics(self.cong_window, self.receiver_window, self.rtt_est)

            except Exception as e:
                if self.is_running:
                    self.log(f"!! Error in ACK listener: {e}")

    def retransmit(self):
        while self.is_running:
            time.sleep(0.5)
            now = time.time()
            for seq in range(self.base, self.next_seq):
                if seq in self.packets:
                    packet, sent_time, retries = self.packets[seq]
                    if now - sent_time > self.rtt_est:
                        self.log(f"!!! Timeout! Retransmitting #{seq}")
                        self.sock.sendto(packet, (SERVER_IP, SERVER_PORT))
                        self.packets[seq][1] = now
                        self.packets[seq][2] += 1
                        self.ssthresh = max(int(self.cong_window / 2), 1)
                        self.cong_window = 1
                        self.dup_ack_count = 0  # Reset duplicate ACK counter on timeout
                        self.cwnd_label.config(text=f"Congestion Window: {self.cong_window:.1f}")
                        self.update_window()
                        self.update_visualization()
                        self.update_metrics(self.cong_window, self.receiver_window, self.rtt_est)

    def listen_flow_feedback(self):
        feedback_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        feedback_sock.bind((SERVER_IP, FLOW_FEEDBACK_PORT))
        while self.is_running:
            try:
                data, _ = feedback_sock.recvfrom(1024)
                self.receiver_window = int(data.decode())
                self.rwnd_label.config(text=f"Receiver Window: {self.receiver_window}")
                self.log(f">> Receiver buffer: {self.receiver_window} slots")
                self.update_window()
                self.update_visualization()
                self.update_metrics(self.cong_window, self.receiver_window, self.rtt_est)
            except Exception as e:
                if self.is_running:
                    self.log(f"!! Error in flow feedback: {e}")

    def update_window(self):
        window_size = int(min(self.receiver_window, self.cong_window))
        self.effective_label.config(text=f"Effective Window: {window_size}")
        self.log(f"\\ Effective window: {window_size}")


if __name__ == "__main__":
    root = tk.Tk()
    app = SenderGUI(root)
    root.mainloop()
#receiver.py
import socket
import threading
import tkinter as tk
import time
from tkinter import scrolledtext, ttk
from shared_utils import unpack_packet, SERVER_IP, SERVER_PORT, ACK_PORT, FLOW_FEEDBACK_PORT, MAX_BUFFER_SIZE


class ReceiverGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Reliable UDP Receiver")

        self.setup_ui()
        self.init_network()
        self.setup_graph()

    def setup_ui(self):
        # Main frames
        self.control_frame = tk.Frame(self.root)
        self.control_frame.pack(pady=5)

        self.status_frame = tk.Frame(self.root)
        self.status_frame.pack(pady=5)

        self.log_frame = tk.Frame(self.root)
        self.log_frame.pack(pady=5)

        # Control panel
        self.start_btn = tk.Button(self.control_frame, text="Start Receiver", command=self.start_receiver)
        self.start_btn.pack(side=tk.LEFT, padx=5)

        self.stop_btn = tk.Button(self.control_frame, text="Stop Receiver", command=self.stop_receiver,
                                  state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)

        # Status indicators
        self.status_label = tk.Label(self.status_frame, text="Status: Not Running")
        self.status_label.pack()

        self.buffer_status = ttk.Progressbar(self.status_frame, orient=tk.HORIZONTAL, length=200, mode='determinate')
        self.buffer_status.pack(pady=5)
        self.update_buffer_status(0)

        # Log area
        self.log_area = scrolledtext.ScrolledText(self.log_frame, width=80, height=15)
        self.log_area.pack()

        # Packet visualization
        self.packet_canvas = tk.Canvas(self.root, width=600, height=100, bg='white')
        self.packet_canvas.pack(pady=10)

    def setup_graph(self):
        """Add a graph to visualize metrics"""
        self.graph_frame = tk.Frame(self.root)
        self.graph_frame.pack(pady=10)

        # Create a canvas for the graph
        self.graph_canvas = tk.Canvas(self.graph_frame, width=600, height=200, bg='white')
        self.graph_canvas.pack()

        # Graph data storage
        self.buffer_history = []
        self.throughput_history = []
        self.packet_loss_history = []
        self.received_packets = 0
        self.last_update_time = 0
        self.max_history_points = 50

        # Draw initial graph
        self.draw_graph()

    def init_network(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((SERVER_IP, SERVER_PORT))

        self.recv_buffer = {}
        self.received_seqs = set()
        self.expected_seq = 0
        self.receiver_window = MAX_BUFFER_SIZE
        self.is_running = False

    def log(self, message):
        self.log_area.insert(tk.END, message + "\n")
        self.log_area.see(tk.END)
        self.root.update()

    def update_buffer_status(self, used):
        percentage = (used / MAX_BUFFER_SIZE) * 100
        self.buffer_status['value'] = percentage
        self.buffer_status[
            'style'] = 'red.Horizontal.TProgressbar' if percentage > 80 else 'green.Horizontal.TProgressbar'

    def draw_packet(self, seq, status):
        x = 50 + (seq % 20) * 25
        y = 50
        color = 'green' if status == 'received' else 'red' if status == 'missing' else 'blue'
        self.packet_canvas.create_oval(x, y, x + 20, y + 20, fill=color)
        self.packet_canvas.create_text(x + 10, y + 10, text=str(seq), fill="white")

    def draw_graph(self):
        """Draw the graph with current data"""
        self.graph_canvas.delete("all")
        width = 600
        height = 200
        padding = 50

        # Draw axes
        self.graph_canvas.create_line(padding, height - padding, width - padding, height - padding, width=2)  # X-axis
        self.graph_canvas.create_line(padding, height - padding, padding, padding, width=2)  # Y-axis

        # Draw labels
        self.graph_canvas.create_text(width // 2, height - 10, text="Time")
        self.graph_canvas.create_text(10, height // 2, text="Value", angle=90)

        # Draw legend
        self.graph_canvas.create_text(width - 100, 20, text="Buffer Usage", fill="blue")
        self.graph_canvas.create_text(width - 100, 40, text="Throughput", fill="green")
        self.graph_canvas.create_text(width - 100, 60, text="Packet Loss", fill="red")

        # Draw grid lines
        for i in range(0, 101, 20):
            y = height - padding - (height - 2 * padding) * i / 100
            self.graph_canvas.create_line(padding, y, width - padding, y, dash=(2, 2), fill="gray")
            self.graph_canvas.create_text(padding - 10, y, text=f"{i}%")

        # Plot data if we have enough points
        if len(self.buffer_history) > 1:
            # Normalize all data to 0-100 scale for display
            max_val = max(max(self.buffer_history),
                          max(self.throughput_history or [0]),
                          max(self.packet_loss_history or [0])) or 1

            # Plot buffer usage (blue)
            for i in range(1, len(self.buffer_history)):
                x1 = padding + (width - 2 * padding) * (i - 1) / self.max_history_points
                y1 = height - padding - (height - 2 * padding) * self.buffer_history[i - 1] / max_val
                x2 = padding + (width - 2 * padding) * i / self.max_history_points
                y2 = height - padding - (height - 2 * padding) * self.buffer_history[i] / max_val
                self.graph_canvas.create_line(x1, y1, x2, y2, fill="blue", width=2)

            # Plot throughput (green)
            if self.throughput_history:
                for i in range(1, len(self.throughput_history)):
                    x1 = padding + (width - 2 * padding) * (i - 1) / self.max_history_points
                    y1 = height - padding - (height - 2 * padding) * self.throughput_history[i - 1] / max_val
                    x2 = padding + (width - 2 * padding) * i / self.max_history_points
                    y2 = height - padding - (height - 2 * padding) * self.throughput_history[i] / max_val
                    self.graph_canvas.create_line(x1, y1, x2, y2, fill="green", width=2)

            # Plot packet loss (red)
            if self.packet_loss_history:
                for i in range(1, len(self.packet_loss_history)):
                    x1 = padding + (width - 2 * padding) * (i - 1) / self.max_history_points
                    y1 = height - padding - (height - 2 * padding) * self.packet_loss_history[i - 1] / max_val
                    x2 = padding + (width - 2 * padding) * i / self.max_history_points
                    y2 = height - padding - (height - 2 * padding) * self.packet_loss_history[i] / max_val
                    self.graph_canvas.create_line(x1, y1, x2, y2, fill="red", width=2)

        # Schedule next update
        if self.is_running:
            self.root.after(1000, self.draw_graph)

    def update_metrics(self, buffer_usage, throughput, packet_loss):
        """Update the metrics for the graph"""
        self.buffer_history.append(buffer_usage)
        if len(self.buffer_history) > self.max_history_points:
            self.buffer_history.pop(0)

        if throughput is not None:
            self.throughput_history.append(throughput)
            if len(self.throughput_history) > self.max_history_points:
                self.throughput_history.pop(0)

        if packet_loss is not None:
            self.packet_loss_history.append(packet_loss)
            if len(self.packet_loss_history) > self.max_history_points:
                self.packet_loss_history.pop(0)

    def send_flow_feedback(self):
        while self.is_running:
            flow_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            available_space = MAX_BUFFER_SIZE - len(self.recv_buffer)
            flow_sock.sendto(str(available_space).encode(), (SERVER_IP, FLOW_FEEDBACK_PORT))
            flow_sock.close()
            threading.Event().wait(1)

    def start_receiver(self):
        self.is_running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.status_label.config(text="Status: Running")

        threading.Thread(target=self.send_flow_feedback, daemon=True).start()
        threading.Thread(target=self.receive_packets, daemon=True).start()
        self.log("[OK] Receiver started and listening...")
        self.draw_graph()

    def stop_receiver(self):
        self.is_running = False
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.status_label.config(text="Status: Stopped")
        self.log("[END] Receiver stopped")

    def receive_packets(self):
        start_time = time.time()
        packet_count = 0

        while self.is_running:
            try:
                packet, sender_addr = self.sock.recvfrom(1024)
                try:
                    seq, message = unpack_packet(packet)
                except Exception as e:
                    self.log(f"!! Failed to unpack: {e}")
                    continue

                packet_count += 1
                current_time = time.time()

                # Calculate throughput once per second
                if current_time - start_time > 1:
                    throughput = packet_count / (current_time - start_time)
                    packet_count = 0
                    start_time = current_time
                else:
                    throughput = None

                self.log(f"\n[OK] Received packet #{seq}: {message}")
                self.draw_packet(seq, 'received')

                # Case 1: Packet is exactly what we expected
                if seq == self.expected_seq:
                    self.log(f"[IN-ORDER] Processing packet #{seq}")
                    # Deliver to application
                    self.log(f"[DELIVERED] Packet #{seq}: {message}")

                    # Move expected_seq forward
                    self.expected_seq += 1

                    # Immediately send ACK for this packet
                    self.send_ack(seq)

                    # Check if next packets are buffered and can be delivered
                    while self.expected_seq in self.recv_buffer:
                        self.log(
                            f"[BUFFERED->DELIVERED] Packet #{self.expected_seq}: {self.recv_buffer[self.expected_seq]}")
                        del self.recv_buffer[self.expected_seq]
                        # Send ACK for each consecutive delivered packet
                        self.send_ack(self.expected_seq)
                        self.expected_seq += 1

                    self.update_buffer_status(len(self.recv_buffer))

                # Case 2: Packet is a duplicate (already processed)
                elif seq < self.expected_seq:
                    self.log(f"[DUPLICATE] Already processed packet #{seq}")
                    # Send ACK for highest in-order packet we have
                    self.send_ack(self.expected_seq - 1)

                # Case 3: Packet is out-of-order (future packet)
                elif seq > self.expected_seq:
                    self.log(f"[OUT-OF-ORDER] Buffering packet #{seq}")
                    if seq not in self.recv_buffer:  # Only store if new
                        self.recv_buffer[seq] = message
                        self.update_buffer_status(len(self.recv_buffer))

                    # Send ACK for highest in-order packet
                    self.send_ack(self.expected_seq - 1)

                # Update metrics
                buffer_usage = len(self.recv_buffer) / MAX_BUFFER_SIZE * 100
                packet_loss = 0
                self.update_metrics(buffer_usage, throughput, packet_loss)

            except socket.timeout:
                continue
            except Exception as e:
                if self.is_running:
                    self.log(f"!! Error in receive_packets: {e}")

    def send_ack(self, ack_num):
        """Helper method to send ACKs"""
        ack_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ack_sock.sendto(str(ack_num).encode(), (SERVER_IP, ACK_PORT))
        ack_sock.close()
        self.log(f"[ACK SENT] #{ack_num}")

if __name__ == "__main__":
    root = tk.Tk()
    style = ttk.Style()
    style.configure('green.Horizontal.TProgressbar', foreground='green', background='green')
    style.configure('red.Horizontal.TProgressbar', foreground='red', background='red')
    app = ReceiverGUI(root)
    root.mainloop()